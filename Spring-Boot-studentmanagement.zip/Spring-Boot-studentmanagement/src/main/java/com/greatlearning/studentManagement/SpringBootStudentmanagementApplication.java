package com.greatlearning.studentManagement;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringBootStudentmanagementApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringBootStudentmanagementApplication.class, args);
	}

}
